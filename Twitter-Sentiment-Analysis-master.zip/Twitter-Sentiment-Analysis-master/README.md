# Twitter-Sentiment-Analysis
Python Script for sentimental analysis of tweets.

## Requirements:-
* Python
* Tweepy
* TextBlob
* Pandas

## Dependencies:-
1. Install Tweepy `pip install tweepy`
2. Install TextBlob `pip install -U textblob`
3. Additional Dependency `python -m textblob.download_corpora`



More enhancements coming soon!

## Enhancements:-
* Added new project (Airline Sentiment)


##### Developed By Manan Manwani
